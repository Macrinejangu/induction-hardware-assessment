INDUCTION HARDWARE PART 1 RESEARCH PACKAGE
Research captured 25 October 2026

Main deliverable
Induction_Hardware_Part_1_Competitive_Analysis.docx is the editable strategy document, supplied separately. Prose and comparison tables are editable. The document has 15 rendered pages and covers sections 1.1 through 1.7, eight findings for Part 2, the process log, AI corrections and source register.

Evidence
54 original browser screenshots, plus 14 cropped excerpts.
47 paired browser text captures.
Original captures are in evidence/. Crops are in evidence/excerpts/.
Crops preserve source pixels and are not recreated platform views.

Open evidence_gallery.html after extracting this ZIP. The gallery links to the original images and source pages.
evidence_index.csv and evidence_index.json contain source URLs, file-save timestamps in Africa/Nairobi and SHA-256 hashes.
claim_ledger.csv maps observation families to evidence and limitations.
ai_process_record.txt records the exact task prompt, actual workflow examples, queries, limits and source checks.
ai_correction_before_after.txt records a corrected statement from the initial AI-authored draft.
Part_1_readable_text.txt supplies a plain text version of the final document.

Scope and pending evidence
This is a dated public snapshot. Meta counts are approximate broad advertiser-page results. Google domain inventories use Any time and all formats/platforms. Search used US parameters but retained Kenyan currency localization. Final USD delivered totals, code redemption, controlled US auction sampling, historical 2025 BFCM creatives, complete video reviews and blocked landing views remain unverified where stated. An original AI-interface screenshot was blocked by the app, so the exact prompt and workflow are supplied as text. No competitor spend, ROAS, CPA, keyword volume or CPC is fabricated.

Quality check
The editable document was rendered and all 15 pages reviewed. The blank page found in an earlier render was removed. Original evidence hashes were checked before packaging.
