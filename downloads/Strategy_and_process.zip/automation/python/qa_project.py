"""Offline project and synthetic launch QA. No network, account writes or approvals."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
import csv, json, hashlib, argparse, math
from forecast import forecast

def rows(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def validate_launch(record,now):
    errors=[]
    for key in ['sku','platform','final_url','feed_price','landing_price','stock','offer_approved','purchase_test_passed','data_as_of','offer_expires_at']:
        if key not in record or record[key] is None or record[key]=='': errors.append('Missing '+key)
    if errors:return errors
    u=urlparse(str(record['final_url'])); q=parse_qs(u.query)
    if u.scheme!='https' or not u.netloc:errors.append('Invalid final URL')
    for k in ['utm_source','utm_medium','utm_campaign']:
        if not q.get(k):errors.append('Missing '+k)
    if record['platform'] not in ['Google','Meta']:errors.append('Unknown platform')
    for k in ['offer_approved','purchase_test_passed']:
        if record[k] is not True:errors.append(k+' must be explicit true')
    try:
        price,landing,stock=[float(record[k]) for k in ['feed_price','landing_price','stock']]
        if not all(math.isfinite(x) for x in [price,landing,stock]):raise ValueError()
        if price<=0 or landing<=0:errors.append('Non-positive price')
        if abs(price-landing)>.01:errors.append('Price mismatch')
        if stock<=0:errors.append('No stock')
    except (TypeError,ValueError):errors.append('Invalid numeric input')
    try:
        asof=datetime.fromisoformat(record['data_as_of']); expiry=datetime.fromisoformat(record['offer_expires_at'])
        if asof.tzinfo is None or expiry.tzinfo is None:raise ValueError()
        age=(now-asof).total_seconds()
        if age<0 or age>24*3600:errors.append('Stale or future source')
        if expiry<=now:errors.append('Expired offer')
    except (TypeError,ValueError):errors.append('Invalid timezone-aware timestamp')
    return errors

def run(root):
    checks=[]
    def check(name,passed,detail):checks.append({'check':name,'passed':bool(passed),'detail':detail})
    phases=rows(root/'strategy/budget-phases.csv');nov=[r for r in phases if r['start'].startswith('2026-11')]
    check('November phase ceiling',sum(float(r['total_usd']) for r in nov)==150000,'December excluded')
    check('Phase splits and totals',all(abs(float(r['google_usd'])+float(r['meta_usd'])-float(r['total_usd']))<.001 and abs(float(r['google_usd'])/float(r['total_usd'])-.6)<.0001 for r in phases),'Google 60 percent, Meta 40 percent')
    cumulative=0;valid=True
    for r in nov:
        cumulative+=float(r['total_usd']);valid &= cumulative==float(r['cumulative_in_month_usd'])
    check('Cumulative phase labels',valid,'15k, 40k, 85k, 150k')
    camps=rows(root/'strategy/campaign-structure.csv')
    check('Campaign totals',sum(float(r['november_cap_usd']) for r in camps)==150000 and sum(float(r['november_cap_usd']) for r in camps if r['platform']=='Google')==90000,'Google 90k, Meta 60k')
    recalculated=forecast(root);stored=rows(root/'strategy/forecast-results.csv')
    matches=True
    for calc,saved in zip(recalculated,stored):
        for k in ['google_visits','meta_impressions','meta_visit_proxy','orders_after_haircut','net_revenue_usd','revenue_roas','media_cac_usd','contribution_after_media_usd']:
            matches &= abs(float(calc[k])-float(saved[k]))<.01
    check('Forecast re-evaluates from editable inputs',len(recalculated)==len(stored)==3 and matches,'All three cases agree with displayed model')
    check('Independent planning-case control',abs(float(stored[1]['net_revenue_usd'])-631800)<.01 and abs(float(stored[1]['contribution_after_media_usd'])-7950)<.01,'Independent expected-value check')
    evidence=rows(root/'evidence/evidence-register.csv');missing=[]
    for r in evidence:
        s=r['screenshot']
        if s=='Not captured':continue
        p=root/'evidence'/s if '/' in s else root/'evidence/screenshots'/s
        if not p.is_file():missing.append(s)
    check('Evidence paths',not missing,missing or 'Every registered screenshot resolves')
    duplicates=len(evidence)-len({r['evidence_id'] for r in evidence})
    check('Evidence IDs',duplicates==0,'Namespaced legacy IDs avoid GOOGLE and original E-ID collisions')
    idx=rows(root/'evidence/codex-original/part-1/evidence_index.csv');bad=[]
    for r in idx:
        p=root/'evidence/codex-original/part-1/evidence'/r['file']
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:bad.append(r['file'])
    check('Legacy evidence hashes',not bad,bad or f'{len(idx)} indexed original files match SHA-256')
    audit=rows(root/'research/google/google-audit.csv')
    check('Google audit populated',len(audit)>=12 and any(r['result_type']=='Sponsored Shopping product card' for r in audit),'Historical capture types separated from keyword evidence')
    fixture=json.loads((root/'automation/python/fixtures/launch-synthetic.json').read_text());now=datetime.fromisoformat(fixture['as_of'])
    base=fixture['valid_record'];cases=[('valid',{},False),('missing price',{'feed_price':None},True),('mismatch',{'landing_price':8000},True),('no stock',{'stock':0},True),('unapproved',{'offer_approved':False},True),('string true',{'purchase_test_passed':'true'},True),('expired',{'offer_expires_at':'2026-10-25T00:00:00+00:00'},True),('stale',{'data_as_of':'2026-10-24T00:00:00+00:00'},True),('missing UTM',{'final_url':'https://example.invalid/range'},True),('nan price',{'feed_price':'nan'},True)]
    for name,patch,fail in cases:
        err=validate_launch({**base,**patch},now);check('Synthetic launch: '+name,bool(err)==fail,err or 'Pass on synthetic inputs only')
    check('Required execution gates remain open',all(r['status'].startswith('Open') for r in rows(root/'strategy/prerequisites.csv')),'Local QA never closes client access gates')
    for rel in ['research/assumptions.csv','research/google/google-audit.csv','research/landing-pages/landing-page-audit.csv','strategy/findings-to-actions.csv','strategy/budget-phases.csv']:
        parsed=rows(root/rel);check('CSV schema: '+rel,all(None not in r and all(v is not None for v in r.values()) for r in parsed),'No shifted columns or ragged rows')
    return {'scope':'Offline package and synthetic fixtures only. No live account, checkout, consent or event verification.','as_of':'2026-10-26','checks':checks,'passed':all(r['passed'] for r in checks),'pending_submission':['Optional original ZLINE error exchange screenshot; current overconfident-title example is captured in AI-REVIEW-003','Personal review and edits','Honest total elapsed time record'],'execution_gates':'Open, client access required'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--report',type=Path);a=p.parse_args()
    result=run(a.project_root)
    if a.report:a.report.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2));raise SystemExit(0 if result['passed'] else 1)
