"""Recalculate scenario CSVs. All inputs are assumptions, not actual account data."""
from pathlib import Path
import csv, argparse, math

def load(p):
    with p.open(newline='',encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def forecast(root):
    assumptions={r['parameter']:float(r['value']) for r in load(root/'research/assumptions.csv')}
    campaigns=load(root/'strategy/campaign-structure.csv')
    google=sum(float(r['november_cap_usd']) for r in campaigns if r['platform']=='Google')
    meta=sum(float(r['november_cap_usd']) for r in campaigns if r['platform']=='Meta')
    total=google+meta
    aov=assumptions['Net AOV']; margin=assumptions['Pre-ad contribution']; overlap=assumptions['Overlap haircut']
    if not (total>0 and aov>0 and 0<=margin<=1 and 0<=overlap<1):
        raise ValueError('Invalid contribution, overlap, AOV or budget input')
    out=[]
    for r in load(root/'strategy/forecast-inputs.csv'):
        cpc,gcvr,cpm,ctr,mcvr=[float(r[k]) for k in ['google_blended_cpc_usd','google_purchase_rate','meta_cpm_usd','meta_outbound_ctr','meta_purchase_rate']]
        if not all(math.isfinite(x) for x in [cpc,gcvr,cpm,ctr,mcvr]):
            raise ValueError('Non-finite forecast input')
        if cpc<=0 or cpm<=0 or any(x<0 or x>1 for x in [gcvr,ctr,mcvr]):
            raise ValueError('Invalid cost or probability input')
        gv=google/cpc; mi=meta/cpm*1000; mv=mi*ctr
        orders=(gv*gcvr+mv*mcvr)*(1-overlap); revenue=orders*aov
        out.append({**r,'google_visits':gv,'meta_impressions':mi,'meta_visit_proxy':mv,'orders_after_haircut':orders,'net_revenue_usd':revenue,'revenue_roas':revenue/total,'media_cac_usd':total/orders if orders else 'Not available: zero orders','contribution_after_media_usd':revenue*margin-total})
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('project_root',type=Path);p.add_argument('--write',action='store_true');a=p.parse_args()
    rows=forecast(a.project_root)
    if a.write:
        with (a.project_root/'strategy/forecast-results.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    else:
        for r in rows:print(r['case'],round(r['net_revenue_usd'],2),round(r['revenue_roas'],3))
