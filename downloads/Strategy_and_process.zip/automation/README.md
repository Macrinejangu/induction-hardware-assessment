Local prototype and proposed connected systems

From the project root:
python3 automation/python/qa_project.py . --report qa/validation-report.json
python3 automation/python/forecast.py .
python3 automation/python/forecast.py . --write

The first command performs offline checks and synthetic launch fixtures. The forecast command reads assumption and campaign CSVs, then prints scenarios. --write explicitly replaces forecast-results.csv. If assumptions change, update the editable report before regenerating a final PDF. The local checker validates the supplied reference budget and independent planning-case control, so changed strategy inputs require deliberately updating those controls.

The launch validator accepts an explicit supplied purchase_test_passed flag. It does not run a real purchase test. It does not fetch destinations, inspect pixels, redeem offers or establish consent. This keeps evidence of a field separate from evidence of a live integration.

The n8n JSON documents the design only. Importing the file as a workflow is unsupported. Connected API authentication, approved delivery routes, event diagnostics, offline sales matching and production alert delivery remain proposed. No automation changes campaigns or sends messages.
