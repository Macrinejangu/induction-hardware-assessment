Dated Google evidence reconciliation
26 October 2026

The current user project had five retail/editorial GOOGLE entries and an empty paid-audit header. Those rows remain. They are not Google ad screenshots. Ten initial query themes remain, and required induction-vs-gas and brand queries have been added.

Earlier Codex captures establish separate evidence types:
E07, E13, E14, E16, E19: US destination-domain Transparency inventories, Any time, all formats/platforms. Counts are broad, historical and potentially span advertiser accounts.
E32: Fisher & Paykel refrigerator text ad, last shown 25 October 2026. Not an induction-range ad.
E41: ZLINE range-hood text ad, last shown 25 October 2026. Not proof of induction keyword bids.
E15, E17, E23, E43: saved search snapshots for the required intents. No unsupported sponsored text rank or absence conclusion.
E26: Sponsored Products includes Best Buy selling Fisher & Paykel. KES localization persisted with USD values. This is a mixed-location session, not controlled US auction research.

Source screenshots and paired browser text are in evidence/codex-original/part-1/evidence. The original evidence index records saved-file times in Africa/Nairobi and SHA-256. Re-integration dates do not replace capture dates.

Earlier Codex Meta ZLINE inventory was about 140, while the current project records 150. Counts belong to distinct saved views and need not match. No unique-creative total or trend is inferred. Earlier five-company competitor selection stays archived. The current six remain primary.

No bid, CPC, search volume, competitor spend, CPA, ROAS, induction-specific impression share or keyword-market gap is verified by these captures. No 2025 BFCM creative has been established. Those unknowns are retained.
